import requests

BASE = "http://localhost:8000"

dummy_portfolios = [
    {
        "name": "Tech Growth",
        "assets": [
            {"ticker": "AAPL", "name": "Apple Inc.", "asset_type": "stock", "sector": "Technology", "region": "US", "market_price": 180, "units_held": 50, "is_hedge": False, "hedges_asset": ""},
            {"ticker": "GOOGL", "name": "Alphabet", "asset_type": "stock", "sector": "Technology", "region": "US", "market_price": 2800, "units_held": 10, "is_hedge": False, "hedges_asset": ""}
        ]
    },
    {
        "name": "Global Diversified",
        "assets": [
            {"ticker": "BND", "name": "Vanguard Total Bond", "asset_type": "bond", "sector": "Government Bonds", "region": "Global", "market_price": 80, "units_held": 100, "is_hedge": False, "hedges_asset": ""},
            {"ticker": "VTI", "name": "Total US Market", "asset_type": "stock", "sector": "Finance", "region": "US", "market_price": 230, "units_held": 20, "is_hedge": False, "hedges_asset": ""}
        ]
    }
]

# Create portfolios and capture IDs
portfolio_ids = []
for p in dummy_portfolios:
    res = requests.post(f"{BASE}/portfolios", json=p)
    res.raise_for_status()
    portfolio_ids.append(res.json()["id"])
    print(f"Created portfolio: {p['name']}")

# Create archive entries
dummy_archives = [
    {
        "portfolio_id": portfolio_ids[0],
        "original_question": "Should I worry about my tech exposure?",
        "openai_response": "Your tech exposure is significant but stable. Apple and Alphabet are strong holdings.",
        "article_ids": ["https://example.com/aapl-outlook", "https://example.com/googl-analysis"],
        "summary_tags": ["Technology", "US", "stock"]
    },
    {
        "portfolio_id": portfolio_ids[1],
        "original_question": "Is this portfolio recession-proof?",
        "openai_response": "Good bond allocation. Diversification helps reduce downside risk.",
        "article_ids": ["https://example.com/bond-strategy"],
        "summary_tags": ["bond", "global", "diversified"]
    }
]

for a in dummy_archives:
    res = requests.post(f"{BASE}/archives", json=a)
    res.raise_for_status()
    print(f"Archived: {a['original_question']}")

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.portfolio_crud import get_all_portfolios, create_portfolio, delete_portfolio, update_portfolio
from app.models.schemas import PortfolioCreate, PortfolioOut
from app.db.session import get_db

router = APIRouter()

@router.get("/portfolios", response_model=list[PortfolioOut])
async def list_portfolios(db: AsyncSession = Depends(get_db)):
    return await get_all_portfolios(db)

@router.post("/portfolios", response_model=PortfolioOut)
async def add_portfolio(portfolio: PortfolioCreate, db: AsyncSession = Depends(get_db)):
    return await create_portfolio(db, portfolio)

@router.delete("/portfolios/{id}")
async def remove_portfolio(id: int, db: AsyncSession = Depends(get_db)):
    deleted = await delete_portfolio(db, id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Portfolio not found")
    return {"deleted": True}

@router.put("/portfolios/{id}", response_model=PortfolioOut)
async def update_portfolio_route(id: int, portfolio: PortfolioCreate, db: AsyncSession = Depends(get_db)):
    return await update_portfolio(db, id, portfolio)


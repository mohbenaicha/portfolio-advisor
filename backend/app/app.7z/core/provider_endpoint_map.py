endpoint_map = {
    "validate_prompt": f"/validate-prompt",
    "validate_investment_goal": "/validate-investment-goal",
    "determine_if_augmentation_required": "/determine-augmentation",
    "retrieve_news": "/retrieve-news",
    "prepare_advice_template": "/generate-advice-template",
}